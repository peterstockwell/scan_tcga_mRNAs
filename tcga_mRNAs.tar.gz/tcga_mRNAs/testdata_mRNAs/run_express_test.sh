#!/bin/sh
awk -f ../scan_tcga_mRNAs.awk wanted_field=3 barcode_list="test_barcodes.txt" log2=1 barcodetofilefile="test_FILES_4_barcodes.txt" file_extension=".rsem.genes.results" tcga_dir="mRNAs_testdata/" test_genelist.txt
exit
